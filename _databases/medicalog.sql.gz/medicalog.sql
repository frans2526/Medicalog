-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 05, 2013 at 10:26 PM
-- Server version: 5.1.44
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `medicalog`
--

-- --------------------------------------------------------

--
-- Table structure for table `Calendars`
--

CREATE TABLE IF NOT EXISTS `Calendars` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` text,
  `start` datetime DEFAULT NULL,
  `end` datetime DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `Doctor_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Doctor_id`),
  KEY `fk_Calendar_Doctor1` (`Doctor_id`),
  KEY `title` (`title`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `Calendars`
--

INSERT INTO `Calendars` (`id`, `title`, `content`, `start`, `end`, `status`, `Doctor_id`) VALUES
(-1, NULL, NULL, NULL, NULL, -1, -1),
(21, 'JeaJJ', 'Ïô', '2012-06-15 10:20:00', '2012-06-15 10:30:00', 1, 1),
(22, 'Jean Dûpont', 'Bonjour test 1 2 3 ôï@&amp;é', '2012-06-13 11:00:00', '2012-06-13 11:20:00', 1, 1),
(23, 'Roger Bière', 'Vessie &lt;script&gt;alert(&#039;je t ai eu !&#039;)&lt;/script&gt;', '2012-06-14 08:20:00', '2012-06-14 08:40:00', 1, 1),
(24, 'Magda de la Bouralière de machin Brolle', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\r\ntempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\r\nquis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\r\nconsequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\r\ncillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\r\nproident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2012-06-14 11:20:00', '2012-06-14 11:30:00', 1, 1),
(25, 'Jean dupont', 'Bidouille', '2012-07-04 07:20:00', '2012-07-04 07:40:00', 1, 1),
(27, 'dzdz', 'czzdz', '2012-06-16 10:35:40', '2012-06-16 10:35:42', 1, 1),
(28, 'dz', 'dzdz', '2012-06-16 10:35:59', '2012-06-16 10:36:01', 1, 1),
(29, 'Jean Michel', 'Privé', '2012-06-17 12:00:00', '2012-06-17 15:20:00', 1, 1),
(31, '', '', '1999-11-30 00:00:00', '1999-11-30 00:00:00', 1, 1),
(32, '', '', '1999-11-30 00:00:00', '1999-11-30 00:00:00', 1, 1),
(33, '&lt;h1&gt;Paul&lt;h1&gt;', 'Scan &lt;script&gt;alert(&#039;Bonjour !&#039;);&lt;/script&gt;', '2012-06-23 08:00:00', '2012-06-23 08:20:00', 1, 1),
(34, NULL, NULL, NULL, NULL, -1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `Contacts`
--

CREATE TABLE IF NOT EXISTS `Contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fName` varchar(85) NOT NULL,
  `lName` varchar(85) NOT NULL,
  `mail` varchar(100) DEFAULT NULL,
  `tel` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `other` text,
  `Doctors_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Doctors_id`),
  KEY `fk_Contact_Doctor1` (`Doctors_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `Contacts`
--

INSERT INTO `Contacts` (`id`, `fName`, `lName`, `mail`, `tel`, `mobile`, `other`, `Doctors_id`) VALUES
(1, 'Benito', 'Alessandro', '', '', '', 'salut', 1),
(3, 'ML', 'frz', '', '', '', '', 1),
(4, 'rf', 'fr', '', '', '', '', 1),
(5, 'fe', 'dz', '', '', '', '', 1),
(6, 'Bendgigi', 'Paul', '', '', '', 'Bonjour !', 1),
(9, 'Versmissen', 'François', 'frans2526@skynet.be', '', '', '&quot;bonjour&quot; et moi je dis &#039;hello&#039;', 1),
(10, 'Versmissen', 'Thomas', '', '', '', '', 1),
(12, 'Versmissen', 'Charlotte', '', '', '', '', 1),
(13, 'Arnould', 'Jean', '', '02/3867625', '0478/645603', '1\r\n2\r\n3', 1),
(14, '', '', NULL, NULL, NULL, '-1', 1),
(15, '', '', NULL, NULL, NULL, '-1', 4);

-- --------------------------------------------------------

--
-- Table structure for table `Doctors`
--

CREATE TABLE IF NOT EXISTS `Doctors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `inamiCode` mediumint(9) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `login` varchar(85) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `firstName` varchar(85) NOT NULL,
  `lastName` varchar(85) NOT NULL,
  `dt_inscri` datetime NOT NULL,
  `dt_AbonNow` datetime DEFAULT NULL,
  `dt_AbonEnd` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `Doctors`
--

INSERT INTO `Doctors` (`id`, `inamiCode`, `mail`, `login`, `password`, `phone`, `firstName`, `lastName`, `dt_inscri`, `dt_AbonNow`, `dt_AbonEnd`) VALUES
(-1, 0, '', 'NULL', 'grvcn5RwKtQYWtSAQoyfv7Udd1OJ0IuTbP2LXYWwFpTh0fr3XoPSgg', NULL, '', '', '0000-00-00 00:00:00', NULL, NULL),
(1, 123456, 'francois@lx4.be', 'frans', 'grvcn5RwKtQYWtSAQoyfv7Udd1OJ0IuTbP2LXYWwFpTh0fr3XoPSgg', NULL, 'François', 'Versmissen', '2012-05-21 09:40:52', NULL, NULL),
(2, 123455, '', 'paul', 'grvcn5RwKtQYWtSAQoyfv7Udd1OJ0IuTbP2LXYWwFpTh0fr3XoPSgg', NULL, 'Nomide', 'Paul', '2012-06-20 14:03:29', NULL, NULL),
(3, 654678, 'roger@hotmail.com', 'roger', 'grvcn5RwKtQYWtSAQoyfv7Udd1OJ0IuTbP2LXYWwFpTh0fr3XoPSgg', '', 'Roger', 'Malherbe', '2012-06-23 09:56:07', NULL, NULL),
(4, 123457, 'frans@lx4.be', 'bidule', 'grvcn5RwKtQYWtSAQoyfv7Udd1OJ0IuTbP2LXYWwFpTh0fr3XoPSgg', '', 'Bidulle', 'Machin', '2012-06-26 11:21:18', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Historys`
--

CREATE TABLE IF NOT EXISTS `Historys` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `date` datetime NOT NULL,
  `Patient_id` int(11) NOT NULL,
  `Doctors_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`,`Patient_id`,`Doctors_id`),
  KEY `fk_History_Patient1` (`Patient_id`),
  KEY `fk_Historys_Doctors1` (`Doctors_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `Historys`
--

INSERT INTO `Historys` (`id`, `content`, `date`, `Patient_id`, `Doctors_id`, `status`) VALUES
(1, 'Maladie du crâne\r\n1\r\n2\r\n3\r\n\r\nêêîrçà\r\n\r\n&quot;Bonjour&quot; ''Hello''\r\n\r\n&lt;script&gt;alert(''bonjour !'');&lt;/script&gt;', '2012-06-23 11:28:52', 2, 1, 1),
(2, 'Coeur', '2012-06-21 14:03:46', 5, 2, 1),
(3, 'Cerveau', '2012-06-22 14:04:40', 4, 1, 1),
(8, '', '2012-06-22 17:50:04', 10, 1, 1),
(9, 'Tu es un gagnant ;-)', '2012-06-22 17:43:50', 12, 1, 1),
(19, '', '0000-00-00 00:00:00', 18, 1, 0),
(20, '', '0000-00-00 00:00:00', 19, 3, 0),
(21, '', '0000-00-00 00:00:00', 20, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `Medias`
--

CREATE TABLE IF NOT EXISTS `Medias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `file` varchar(125) NOT NULL,
  `type` varchar(25) NOT NULL,
  `Posts_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Posts_id`),
  KEY `fk_Medias_Posts1` (`Posts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `Medias`
--


-- --------------------------------------------------------

--
-- Table structure for table `Patients`
--

CREATE TABLE IF NOT EXISTS `Patients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(120) NOT NULL,
  `lastName` varchar(120) NOT NULL,
  `age` date DEFAULT NULL,
  `mutuelle` bigint(12) NOT NULL,
  `phone` varchar(45) DEFAULT NULL,
  `mobile` varchar(45) DEFAULT NULL,
  `mail` varchar(100) DEFAULT NULL,
  `adress` varchar(255) DEFAULT NULL,
  `lastModif` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `Patients`
--

INSERT INTO `Patients` (`id`, `name`, `lastName`, `age`, `mutuelle`, `phone`, `mobile`, `mail`, `adress`, `lastModif`) VALUES
(2, 'Dupont', 'Jean', '2012-06-08', 12345612311, '', '', '', 'Paris', '2012-06-22 13:42:22'),
(4, 'Dupres', 'Jacque', NULL, 298923332, NULL, NULL, NULL, NULL, '2012-06-22 15:39:43'),
(5, 'Musset', 'Alfred', NULL, 298923343, NULL, NULL, NULL, NULL, '2012-06-22 14:02:17'),
(9, 'Versmissen', 'François', '0000-00-00', 89010222935, NULL, NULL, NULL, NULL, '2012-06-22 15:39:48'),
(10, 'Prost', 'Alain', '1965-06-30', 67654467323, '', '', '', 'Paris', '2012-06-22 16:27:26'),
(12, 'Erton', 'Senna', '2001-09-20', 16782676378, '', '', '', 'Los Angeles', '2012-06-22 16:31:33'),
(13, 'NULL', 'NULL', NULL, 0, NULL, NULL, NULL, NULL, NULL),
(18, 'NULL', 'NULL', NULL, 0, NULL, NULL, NULL, NULL, NULL),
(19, 'NULL', 'NULL', NULL, 0, NULL, NULL, NULL, NULL, NULL),
(20, 'NULL', 'NULL', NULL, 0, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Posts`
--

CREATE TABLE IF NOT EXISTS `Posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `type` enum('page','post') DEFAULT NULL,
  `title` varchar(85) NOT NULL,
  `online` tinyint(4) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `slug` varchar(200) NOT NULL,
  `Users_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Users_id`),
  KEY `fk_Posts_Users1` (`Users_id`),
  KEY `type` (`type`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `Posts`
--

INSERT INTO `Posts` (`id`, `content`, `type`, `title`, `online`, `created`, `slug`, `Users_id`) VALUES
(2, '<p>Ici c''est l''accueil !</p>\r\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce eu sapien et neque blandit placerat. Integer a eros neque, quis convallis augue. Nulla bibendum, purus non tristique imperdiet, lectus urna iaculis nisi, feugiat scelerisque magna eros ut lectus. Phasellus condimentum, ante vel mattis egestas, felis enim semper lorem, in varius odio tellus ut risus. Vestibulum non augue nec ipsum aliquam elementum ut ut elit. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec vel mi purus, vel imperdiet quam. Fusce ac mi enim, eu tempor felis.</p>\r\n<p>Sed at orci nec dui rutrum congue nec ut lorem. Proin rutrum consectetur ante eu laoreet. Suspendisse ut ultricies orci. Donec metus quam, sodales vel malesuada mollis, sagittis at erat. Donec fermentum, mauris ut malesuada tincidunt, leo enim interdum metus, sed semper augue est non ante. Mauris non sem lorem, in fringilla orci. Donec elementum suscipit sapien nec faucibus. Praesent placerat massa enim, nec congue felis. Sed tortor orci, rhoncus vitae pharetra ac, semper nec est. Nulla et dui in sapien pellentesque malesuada. Vivamus fermentum, lacus a laoreet suscipit, sapien erat pretium quam, et lacinia elit nisi at mauris. Sed quis lorem nulla, eget lacinia libero. Nunc tortor nisi, sodales sed laoreet ac, vulputate nec massa. Integer quam nulla, accumsan eu pulvinar hendrerit, fermentum ac risus.</p>\r\n<p>Ut auctor porttitor orci, in venenatis nisi sodales vel. Vestibulum aliquet diam ac nunc ullamcorper id hendrerit massa vehicula. Ut bibendum aliquet consequat. Donec lobortis sem et felis vestibulum id volutpat ligula rutrum. Maecenas vel diam libero. Ut suscipit auctor vehicula. Quisque vitae tellus id velit bibendum feugiat at aliquam nisi. Maecenas non diam velit. Donec eget neque ullamcorper tellus vestibulum mattis. In hac habitasse platea dictumst. Vivamus congue velit sed mi interdum vulputate posuere felis viverra.</p>\r\n<p>Vestibulum turpis arcu, scelerisque sit amet pellentesque ac, viverra auctor nisl. Aenean lacinia orci in magna tempor viverra. Phasellus ut arcu sit amet enim interdum euismod. Nulla ut lacus id libero congue mattis. Nulla molestie velit sed arcu vulputate posuere. Proin lacinia dictum iaculis. Nulla dui tortor, commodo vitae pharetra in, fermentum ac nunc. Integer et lorem ut ante vehicula dapibus gravida at neque. Cras dapibus erat sit amet nisi rhoncus porttitor. Maecenas volutpat, lectus id suscipit imperdiet, lorem sem eleifend orci, volutpat luctus orci mi et mi. Cras bibendum magna et mi ultricies mollis. Proin risus ipsum, suscipit sed semper nec, viverra at tortor. Aliquam accumsan purus quis metus congue quis molestie mauris pulvinar. Etiam eget nisi id erat congue suscipit quis consectetur dui. Donec et tellus ut lacus lobortis adipiscing a eget elit.</p>\r\n<p>Nunc et justo sem. Praesent mattis eros eget enim gravida vel sagittis magna imperdiet. Nunc varius arcu vitae sem aliquam vitae ullamcorper dui tincidunt. Nullam vehicula laoreet elementum. Cras blandit condimentum sagittis. Proin dolor sapien, egestas in consectetur a, lacinia sit amet turpis. Suspendisse potenti. Sed rhoncus dolor non urna rutrum imperdiet. Suspendisse rutrum, est quis scelerisque molestie, dui nunc molestie nisl, et feugiat tortor massa sed lacus. Nullam ut metus velit. Praesent non metus nisl. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Etiam viverra mattis mi, a egestas mi vehicula et.</p>', 'page', 'Accueil', 1, '2013-01-30 22:01:08', 'accueil', 1),
(3, '<p>Mon contenu bidon !</p>', 'post', 'Mon premier article', 1, '2012-05-23 11:59:42', 'mon-premier-article', 1),
(5, '<p>Voici la charte de confidentialit&eacute;&nbsp;de M&eacute;dicalog.be:</p>\r\n<h3>1)Missions</h3>\r\n<p>Le site &laquo; www.medicalog.be &raquo; permet aux m&eacute;decins g&eacute;n&eacute;ralistes belges francophones de pouvoir sauvegarder de mani&egrave;re permanente le dossier de leurs patients et leurs carnets d''adresses, ainsi que d''organiser leurs rendez-vous dans un calendrier.</p>\r\n<p>Cependant si l''utilisateur d&eacute;cide de se d&eacute;sabonner du service, les informations resteront sauvegard&eacute;es durant 1 mois avant leur destruction.</p>\r\n<h3>2)Vie priv&eacute;e</h3>\r\n<p>Conform&eacute;ment &agrave; la loi europ&eacute;enne 2000/31/CE relative &agrave; l''informatique, aux fichiers et aux libert&eacute;s, l''usager du service dispose d''un droit d''acc&egrave;s, de modification, de rectification, d''effacement des donn&eacute;es &agrave; caract&egrave;re personnel qui le concernent ainsi que d''un droit d''opposition.</p>\r\n<p>Pour exercer ce droit l''usager peut envoyer une demande par mail : <a href="mailto:contact@medicalog.be">contact@medicalog.be</a>.</p>\r\n<p>Vos donn&eacute;es seront utilis&eacute;s de mani&egrave;re statistique et de fa&ccedil;on totalement anonyme.</p>\r\n<h3>3)Droits des tiers</h3>\r\n<p>La structure g&eacute;n&eacute;rale, ainsi que les logiciels, textes, images anim&eacute;es ou fixes, sons et tout autre &eacute;l&eacute;ment composant le site sont la propri&eacute;t&eacute; exclusive de medicalog.be. Toute repr&eacute;sentation et/ou reproduction et/ou exploitation totale ou partielle de ce site Web par quelque proc&eacute;d&eacute; que ce soit, sans l''autorisation expresse de medicalog.be, est interdite et constituerait une contrefa&ccedil;on et suivants du Code de la propri&eacute;t&eacute; intellectuelle.</p>\r\n<p>Les documents &laquo; publics &raquo; ou &laquo; officiels &raquo; ne sont couverts par aucun droit d''auteur et peuvent donc &ecirc;tre reproduits librement. C''est le cas notamment pour les discours, les textes r&eacute;glementaires, etc.</p>\r\n<p>Cependant le bon usage de l''internet veut que la reprise de ces contenus de fa&ccedil;on partielle ou int&eacute;grale mentionne clairement le nom de l''auteur, la source, et le cas &eacute;ch&eacute;ant le lien renvoyant vers le document original en ligne sur le site. Tous les autres contenus pr&eacute;sents sur le site sont couverts par le droit d''auteur.</p>\r\n<p>Toute reprise est d&egrave;s lors conditionn&eacute;e &agrave; l''accord de l''auteur. Ces contenus ne sauraient &ecirc;tre reproduits librement sans le consentement de l''auteur ou ses ayants droit ou ayants cause et sans l''indication de la source.</p>\r\n<p>La marque Medicalog.be, le logo du Medicalog.be, ainsi que les logos et marques des partenaires de Medicalog.be figurant sur le site sont prot&eacute;g&eacute;s.</p>\r\n<p>Toute repr&eacute;sentation et/ou reproduction et/ou exploitation totale ou partielle de ces marques et/ou logos, effectu&eacute;e &agrave; partir des &eacute;l&eacute;ments du site, sont soumis &agrave; l''autorisation expresse de Medicalog.be, selon les dispositions du Code de la propri&eacute;t&eacute; intellectuelle.</p>\r\n<h3>4)E-commerce</h3>\r\n<p>Medicalog.be met &agrave; votre disposition un mode de paiement via PayPal.</p>\r\n<p>Des informations compl&eacute;mentaires pourront vous &ecirc;tre demand&eacute;es pour valider votre commande.<br />Par cons&eacute;quent, et dans le but d''&eacute;viter tout retard, merci de saisir lors de votre commande:- une adresse mail valide avec.- un n&deg;de t&eacute;l&eacute;phone fixe (lieu de travail ou domicile) pour vous joindre &agrave; tout moment dans la journ&eacute;e.<br />De plus, pour toute commande d''un montant sup&eacute;rieur &agrave; un plafond fix&eacute; par medicalog.be, une pi&egrave;ce d''identit&eacute; ainsi qu''un justificatif de domicile et/ou de code inami seront &agrave; nous faire parvenir par t&eacute;l&eacute;copie, mail ou courrier.<br />Nous sommes navr&eacute;s de la g&ecirc;ne occasionn&eacute;e, n&eacute;anmoins ces mesures sont une preuve de volont&eacute; de notre part, de prot&eacute;ger nos clients d''&eacute;ventuelles fraudes &agrave; la carte bancaire.</p>', 'page', 'Confidentialité', 1, '2012-06-25 04:39:30', 'confidentialite', 1),
(6, '<p>Ici c''est le prix !</p>', 'page', 'Prix', 1, '2012-06-23 03:39:35', 'prix', 1),
(7, '<p>Mister Doc</p>', 'page', 'Documentation', 1, '2012-06-23 03:39:50', 'documentation', 1),
(8, '', NULL, '', -1, '2012-06-28 10:34:38', '', -1);

-- --------------------------------------------------------

--
-- Table structure for table `Settings`
--

CREATE TABLE IF NOT EXISTS `Settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `googleCalendar` varchar(45) DEFAULT NULL,
  `Doctors_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`Doctors_id`),
  KEY `fk_Settings_Doctors1` (`Doctors_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `Settings`
--

INSERT INTO `Settings` (`id`, `googleCalendar`, `Doctors_id`) VALUES
(1, 'disable', 1),
(2, 'disable', 3),
(3, 'disable', 4);

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE IF NOT EXISTS `Users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `mail` varchar(100) DEFAULT NULL,
  `login` varchar(85) NOT NULL,
  `password` varchar(54) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `loginPass` (`login`,`password`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`id`, `name`, `mail`, `login`, `password`) VALUES
(-1, NULL, NULL, 'NULL', 'grvcn5RwKtQYWtSAQoyfv7Udd1OJ0IuTbP2LXYWwFpTh0fr3XoPSgg'),
(1, 'Francois Versmissen', NULL, 'frans2526', 'grvcn5RwKtQYWtSAQoyfv7Udd1OJ0IuTbP2LXYWwFpTh0fr3XoPSgg');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `Calendars`
--
ALTER TABLE `Calendars`
  ADD CONSTRAINT `fk_Calendar_Doctor1` FOREIGN KEY (`Doctor_id`) REFERENCES `doctors` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `Contacts`
--
ALTER TABLE `Contacts`
  ADD CONSTRAINT `fk_Contact_Doctor1` FOREIGN KEY (`Doctors_id`) REFERENCES `doctors` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `Historys`
--
ALTER TABLE `Historys`
  ADD CONSTRAINT `fk_Historys_Doctors1` FOREIGN KEY (`Doctors_id`) REFERENCES `doctors` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_History_Patient1` FOREIGN KEY (`Patient_id`) REFERENCES `patients` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `Medias`
--
ALTER TABLE `Medias`
  ADD CONSTRAINT `fk_Medias_Posts1` FOREIGN KEY (`Posts_id`) REFERENCES `posts` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `Posts`
--
ALTER TABLE `Posts`
  ADD CONSTRAINT `fk_Posts_Users1` FOREIGN KEY (`Users_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `Settings`
--
ALTER TABLE `Settings`
  ADD CONSTRAINT `fk_Settings_Doctors1` FOREIGN KEY (`Doctors_id`) REFERENCES `doctors` (`id`) ON UPDATE CASCADE;
